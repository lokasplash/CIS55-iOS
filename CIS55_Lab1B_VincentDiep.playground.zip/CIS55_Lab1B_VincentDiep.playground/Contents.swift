//: Playground - noun: a place where people can play

import UIKit

var dailyPay: [Int] = [Int]()

var totalPay: [Int] = [Int]()

var calcTotalPay: Int = 0




print("Day" + "\t\t" + "Daily Pay($)" + "\t\t" + "Total Pay($)")

for i in 0..<31{
    dailyPay.append(0)
    totalPay.append(0)
    
    dailyPay[i] = Int( pow(2.0, Double(i)))
    calcTotalPay += dailyPay[i]
    totalPay[i] = calcTotalPay
    
    
    print("\(i+1) \t" + String(format: "%12.2f",(Double(dailyPay[i]) / Double(100))) + "\t\t" + String( format:"%12.2f",(Double(totalPay[i]) / Double(100) )))
    
    
}





