//
//  ViewController.swift
//  CIS55Lab1_VincentDiep
//
//  Created by profile on 1/11/16.
//  Copyright © 2016 DeAnza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var txtfield: UITextField!
    
    @IBOutlet weak var btnEnter: UIButton!
    
    @IBOutlet weak var btnReset: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        

        btnEnter.layer.cornerRadius = 5
        btnEnter.layer.borderWidth = 1
        btnEnter.layer.borderColor = UIColor.greenColor().CGColor
        
        btnReset.layer.cornerRadius = 5
        btnReset.layer.borderWidth = 1
        btnReset.layer.borderColor = UIColor.redColor().CGColor
        
        lblTitle.text = "~Change The Label Text~"
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func clickedbtnEnter(sender: AnyObject) {
        
        let name: String = txtfield.text!
        
        lblTitle.text = name
    }

    @IBAction func clickedbtnReset(sender: AnyObject) {
        lblTitle.text = "~Change The Label Text~"
        txtfield.text = ""
    }
}

